<?php

namespace App\Filament\Resources;

use App\Filament\Resources\PegawaiResource\Pages;
use App\Filament\Resources\PegawaiResource\RelationManagers;
use App\Models\Pegawai;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;

// komponen input fornm
use Filament\Forms\Components\RichEditor;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\Toggle;
use Filament\Forms\Components\Radio;

//komponen table
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Columns\BadgeColumn;
use Filament\Tables\Columns\ImageColumn;
use Filament\Tables\Columns\IconColumn;
class PegawaiResource extends Resource
{
    protected static ?string $model = Pegawai::class;

    protected static ?string $navigationIcon = 'heroicon-o-rectangle-stack';

    protected static ?string $navigationLabel = 'Pegawai';
   
    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                TextInput::make('id_pegawai')
                ->required()
                ->placeholder('Masukkan id_pegawai') // Placeholder untuk membantu pengguna
            ,
                TextInput::make('nama_pegawai')
                ->required()
                ->placeholder('Masukkan nama_pegawai') // Placeholder untuk membantu pengguna
            ,
                TextInput::make('nohp_pegawai')
                ->required()
                ->placeholder('Masukkan nohp_pegawai') // Placeholder untuk membantu pengguna
            ,
                TextInput::make('alamat')
                ->required()
                ->placeholder('Masukkan alamat') // Placeholder untuk membantu pengguna 
            ,
                TextInput::make('posisi')
                ->required()
                ->placeholder('Masukkan posisi') // Placeholder untuk membantu pengguna
            ]);
    }

    public static function table(Table $table): Table
{
    return $table
        ->columns([
            Tables\Columns\TextColumn::make('id_pegawai'),
            Tables\Columns\TextColumn::make('nama_pegawai'),
            Tables\Columns\TextColumn::make('nohp_pegawai'),
            Tables\Columns\TextColumn::make('alamat_pegawai'),
            Tables\Columns\TextColumn::make('posisi'),
        ])
        ->filters([
            //
        ])
        ->actions([
            Tables\Actions\ViewAction::make(),
            Tables\Actions\EditAction::make(),
            Tables\Actions\DeleteAction::make(),
        ])
        ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListPegawai::route('/'),
            'create' => Pages\CreatePegawai::route('/create'),
            'edit' => Pages\EditPegawai::route('/{record}/edit'),
        ];
    }
}
